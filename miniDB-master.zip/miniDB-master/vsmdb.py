from database import Database
# create db with name "smdb"
db = Database('vsmdb', load=False)
# create a single table named "classroom"
db.create_table('classroom', ['building', 'room_number', 'capacity'], [str,str,int])
# insert 5 rows
db.insert('classroom', ['B', '101', '500'])
db.insert('classroom', ['A', '514', '10'])
db.insert('classroom', ['Taylor', '3128', '70'])
db.insert('classroom', ['Watson', '100', '30'])
db.insert('classroom', ['C', '120', '50'])
db.insert('classroom', ['B1', '101', '500'])
db.insert('classroom', ['A1', '514', '101'])
#db.insert('classroom', ['Taylor1', '3128', '70'])
#db.insert('classroom', ['Watson1', '100', '30'])
#db.insert('classroom', ['C1', '120', '50'])
db.select('classroom', '*')
db.select('classroom', '*', 'capacity>100')


